A Pen created at CodePen.io. You can find this one at https://codepen.io/freq32/pen/YqOGXB.

 edited from http://jsdo.it/jagarikin/s1Sq

@jagarikin